/**
 * @author Pedro Trindade
 * @version 1.0
 */

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Classe para iniciar o Programa
 */
public class Pow {
    public static void main(String[] args) {
        start();
    }
    /**
     * Menu do jogo
     */
    protected static void start(){
        List<Personagem> personagens = new ArrayList<>();
        System.out.println("-------------------------");
        System.out.println("Bem vindo ao POW!");
        boolean flag=true;
        /*
         Condição para manter o menu/jogo aberto
         */
        while(flag) {
            System.out.println("-------------------------");
            System.out.println("1-Adicionar Personagem");
            System.out.println("2-Imprimir Personagens");
            System.out.println("3-Subir de nivel todas as personagens");
            System.out.println("4-Mostrar Personagens com nivel 10");
            System.out.println("5-Subir nivel dos Magos");
            System.out.println("6-Subir nivel dos Guerreiros");
            System.out.println("7-Subir nivel dos Mercenáros");
            System.out.println("8-Imprimir Magos com sementes de abóbora, Mercenarios com arcos e Guerreiros com armadura");
            System.out.println("9-Imprimir todas as estatisticas de todas as personagens");
            System.out.println("10-Sair do jogo");
            System.out.println("-------------------------");
            Scanner ler = new Scanner(System.in);
            int opcao = ler.nextInt();
            /*
             Uso de Switch-Case para o funcionamento do menu
             */
            switch (opcao) {
                case 1:
                    System.out.println("1-Adicionar Mago\n2-Adicionar Guerreiro\n3-Adicionar Mercenário");
                    Scanner ler2 = new Scanner(System.in);
                    int opcao2 = ler2.nextInt();
                    switch (opcao2) {
                        case 1:
                            System.out.println("Insira o nome do Mago:");
                            Scanner ler3 = new Scanner(System.in);
                            String nome = ler3.nextLine();
                            System.out.println("Selecione a semente/folha para fazer a poção:\n1-Semente de abobora\n2-Folha de Bambu");
                            Scanner ler4 = new Scanner(System.in);
                            int opcao3 = ler4.nextInt();
                            switch (opcao3) {
                                case 1:
                                    personagens.add(new Mago(nome, "Abobora"));
                                    break;
                                case 2:
                                    personagens.add(new Mago(nome, "Bambu"));
                                    break;
                                default:
                                    System.out.println("Opção inválida");
                            }
                            break;
                        case 2:
                            System.out.println("Insira o nome do Guerreiro:");
                            Scanner ler5 = new Scanner(System.in);
                            String nome2 = ler5.nextLine();
                            System.out.println("Tem armadura?\n1-Sim\n2-Nao");
                            Scanner ler6 = new Scanner(System.in);
                            int ar = ler6.nextInt();
                            boolean armadura = false;
                            if (ar == 1) {
                                armadura = true;
                            } else if (ar != 2) {
                                System.out.println("Opção inválida");
                                break;
                            }
                            System.out.println("Selecione a arma do Guerreiro:\n1-Machado\n2-Faca\n3-Espada");
                            Scanner ler7 = new Scanner(System.in);
                            int arma = ler7.nextInt();
                            switch (arma) {
                                case 1:
                                    personagens.add(new Guerreiro(nome2, armadura, "Machado"));
                                    break;
                                case 2:
                                    personagens.add(new Guerreiro(nome2, armadura, "Faca"));
                                    break;
                                case 3:
                                    personagens.add(new Guerreiro(nome2, armadura, "Espada"));
                                    break;
                                default:
                                    System.out.println("Opção inválida");
                            }
                            break;
                        case 3:
                            System.out.println("Insira o nome do Mercenário:");
                            Scanner ler8 = new Scanner(System.in);
                            String nome3 = ler8.nextLine();

                            System.out.println("Selecione a arma do  Mercenário:\n1-Pedras\n2-Pistola\n3-Arco");
                            Scanner ler9 = new Scanner(System.in);
                            int ar2 = ler9.nextInt();

                            System.out.println("Insira Munição:");
                            Scanner ler10 = new Scanner(System.in);
                            int municao = ler10.nextInt();
                            if (municao > 0) {
                                switch (ar2) {
                                    case 1:
                                        personagens.add(new Mercenario(nome3, "Pedras", municao));
                                        break;
                                    case 2:
                                        personagens.add(new Mercenario(nome3, "Pistola", municao));
                                        break;
                                    case 3:
                                        personagens.add(new Mercenario(nome3, "Arco", municao));
                                        break;
                                    default:
                                        System.out.println("Opção inválida");
                                }
                            } else {
                                System.out.println("Valor da munição inválido");
                                break;
                            }
                            break;

                        default:
                            System.out.println("Opção inválida");
                    }
                    break;
                case 2:
                    Personagem.imprime(personagens);
                    break;
                case 3:
                    Personagem.subirNivelAll(personagens);
                    break;
                case 4:
                    Personagem.imprimeMaior10exp(personagens);
                    break;
                case 5:
                    Personagem.subirNivelMagos(personagens);
                    break;
                case 6:
                    Personagem.subirNivelGuerreiros(personagens);
                    break;
                case 7:
                    Personagem.subirNivelMercenarios(personagens);
                    break;
                case 8:
                    Personagem.imprimeTipos(personagens);
                    break;
                case 9:
                    Personagem.imprimeAll(personagens);
                    break;
                case 10:
                    System.out.println("Espero que tenha gostado. Até à próxima!");
                    flag=false;
                    break;
                default:
                    System.out.println("Opção inválida");
            }
        }
    }
}
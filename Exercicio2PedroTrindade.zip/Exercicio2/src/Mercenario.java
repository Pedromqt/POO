/**
 * Classe onde contém os dados da Personagem mais os dados referentes ao mercenário
 */
public class Mercenario extends Personagem{
    /**
     * Arma do mercenário
     */
    private String arma;
    /**
     * Munição da arma do mercenário
     */
    int municao;
    /**
     * Construtor para criar um mercenario (Personagem)
     * @param nome nome do mercenario
     * @param arma arma do mercenario
     * @param municao municao da arma
     */
    protected Mercenario(String nome,String arma,int municao){
        super(nome, 4, 10   , 4);
        this.arma=arma;
        this.municao=municao;
    }
    /**
     * Override do método da classe Personagem para subir nível de um mercenário
     */
    protected void subirNivel(){
        setExp(getExp() + 1);
        setForca(getForca() * 1.08);
        setAgilidade(getAgilidade() * 1.20);
        setInteligencia(getInteligencia() * 1.08);
    }
    /**
     * Override do método da classe Personagem para verificar se o mercenário usa arco
     */
    protected void arcosArmaduraAbobora(){
        if(getArma().equalsIgnoreCase("Arco")){
            System.out.println("Mercenario --> "+getNome()+" <-- | Experiência:"+getExp());
        }
    }
    /**
     * Override do método da classe Personagem para imprimir estatísticas de um mercenário
     */
    protected void imprimeEstatisticas(){
        System.out.println("Mercenario --> "+getNome()+" <-- | Experiência:"+getExp()+" | Força->"+getForca()+" | Agilidade->"+getAgilidade()+" | Inteligência->"+getInteligencia()+" | Arma->"+getArma()+" | Munição->"+getMunicao());
    }
    /**
     * Método para aceder à variável arma
     * @return arma do mercenario
     */
    public String getArma() {
        return arma;
    }
    /**
     * Método para mudar a variável arma
     * @param arma arma do mercenario
     */
    public void setArma(String arma) {
        this.arma = arma;
    }
    /**
     * Método para aceder à variável munição
     * @return municao do mercenario
     */
    public int getMunicao() {
        return municao;
    }
    /**
     * Método para mudar a variável munição
     * @param municao municao da arma
     */
    public void setMunicao(int municao) {
        this.municao = municao;
    }
    /**
     * Método para imprimir nome e nivel de experiência de um mercenário
     */
    public String toString(){
        return "Mercenario --> "+getNome()+" <-- | Experiência:"+getExp();
    }
}

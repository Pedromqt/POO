import java.util.List;
/**
 * Classe principal onde contém os dados em comum das personanges
 */
public class Personagem {
    /**
     * Nome da Personagem
     */
    private String nome;
    /**
     * Nivel de Experiência da personagem
     */
    private int exp;
    /**
     * Nivel da Força
     */
    private double forca;
    /**
     * Nivel da Inteligência
     */
    private double inteligencia;
    /**
     * Nivel da Agilidade
     */
    private double agilidade;

    /**
     * Construtor para criar uma personagem
     * @param nome Nome da personagem
     * @param forca Forca da personagem
     * @param agilidade Agilidade da personagem
     * @param inteligencia Inteligência da personagem
     */
    protected Personagem(String nome,double forca,double agilidade,double inteligencia){
        this.nome=nome;
        this.forca=forca;
        this.inteligencia=inteligencia;
        this.agilidade=agilidade;
        this.exp=(int)(Math.random()*25);
    }

    /**
     * Método para verificar Mercenários com arcos, Magos com sementes de abóbora e Guerreiros com Armadura
     */
    protected void arcosArmaduraAbobora(){}
    /**
     * Método para imprimir Mercenários com arcos, Magos com sementes de abóbora e Guerreiros com Armadura
     * @param personagens Array com todas as personagens
     */
    protected static void imprimeTipos(List<Personagem> personagens){
        for(Personagem personagem : personagens){
            personagem.arcosArmaduraAbobora();
        }
        System.out.println("-------------------------");
    }
    
    /**
     * Método para imprimir personagens com nível de Experiência maior que 10
     * @param personagens Array com todas as personagens
     */
    protected static void imprimeMaior10exp(List<Personagem> personagens){
        for(Personagem personagem : personagens){
            if(personagem.getExp()>10){
                System.out.println(personagem);
            }
        }
        System.out.println("-------------------------");
    }

    /**
     * Método para imprimir toda a informação de uma personagemm
     */
    protected void imprimeEstatisticas(){}

    /**
     * Método que imprime todas as personagens e toda a informação sobre elas
     * @param personagens Array com todas as personagens
     */
    protected static void imprimeAll(List<Personagem> personagens){
        for(Personagem personagem:personagens){
            personagem.imprimeEstatisticas();
        }
    }
    /**
     * Método que imprime todas as personagens e apenas informação relativamente ao nome e nivel de experiência
     * @param personagens Array com todas as personagens
     */
    protected static void imprime(List<Personagem> personagens){
        for(Personagem personagem:personagens){
           System.out.println(personagem);
        }
    }
    /**
     * Método para subir apenas o nível dos magos
     * @param personagens Array com todas as personagens
     */
    protected static void subirNivelMagos(List<Personagem> personagens){
        for(Personagem personagem:personagens) {
            if (personagem instanceof Mago) {
                personagem.subirNivel();
            }
        }
    }

    /**
     * Método para subir apenas o nível dos guerreiros
     * @param personagens Array com todas as personagens
     */
    protected static void subirNivelGuerreiros(List<Personagem> personagens){
        for(Personagem personagem:personagens) {
            if(personagem instanceof Guerreiro){
                personagem.subirNivel();
            }
        }
    }
    /**
     * Método para subir apenas o nível dos Mercenários
     * @param personagens Array com todas as personagens
     */
    protected static void subirNivelMercenarios(List<Personagem> personagens){
        for(Personagem personagem:personagens) {
            if(personagem instanceof Mercenario){
                personagem.subirNivel();
            }
        }
    }

    /**
     * Método para subir nivel de uma personagem
     */
    protected void subirNivel(){}
    /**
     * Método para subir nivel de todas as personagens
     * @param personagens Array com todas as personagens
     */
    protected static void subirNivelAll(List<Personagem> personagens){
        System.out.println("Antes da subida de nivel:");
        Personagem.imprimeAll(personagens);
        for(Personagem personagem:personagens){
            personagem.subirNivel();
        }
        System.out.println("Depois da subida de nivel:");
        Personagem.imprimeAll(personagens);
    }

    /**
     * Método para aceder à variável Forca
     * @return Forca da personagem
     */
    public double getForca() {
        return forca;
    }
    /**
     * Método para mudar a variável Forca
     * @param forca Forca da personagem
     */
    public void setForca(double forca) {
        this.forca = forca;
    }
    /**
     * Método para aceder à variável Inteligência
     * @return Inteligencia
     */
    public double getInteligencia() {
        return inteligencia;
    }
    /**
     * Método para mudar a variável Inteligência
     * @param inteligencia Inteligencia da personagem
     */
    public void setInteligencia(double inteligencia) {
        this.inteligencia = inteligencia;
    }
    /**
     * Método para aceder à variável Agilidade
     * @return Agilidade da personagem
     */
    public double getAgilidade() {
        return agilidade;
    }
    /**
     * Método para mudar a variável Agilidade
     * @param agilidade Agilidade da personagem
     */
    public void setAgilidade(double agilidade) {
        this.agilidade = agilidade;
    }
    /**
     * Método para aceder à variável Experiência
     * @return Experiência da personagem
     */
    public int getExp() {
        return exp;
    }
    /**
     * Método para mudar a variável Experiência
     * @param exp Experiência da personagem
     */
    public void setExp(int exp) {
        this.exp = exp;
    }
    /**
     * Método para aceder à variável Nome
     * @return nome da personagem
     */
    public String getNome() {
        return nome;
    }
    /**
     * Método para mudar a variável Nome
     * @param nome nome da personagem
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
}
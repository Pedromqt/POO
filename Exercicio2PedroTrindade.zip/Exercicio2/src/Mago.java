/**
 * Classe onde contém os dados da Personagem mais os dados referentes ao mago
 */
public class Mago extends Personagem {
    private String semente;
    /**
     * Construtor para criar um mago (Personagem)
     * @param nome nome do mago
     * @param semente semente do mago
     */
    protected Mago(String nome,String semente){
        super(nome, 2, 4, 9);
        this.semente=semente;
    }
    /**
     * Override do método da classe Personagem para verificar se o mago tem semente de abobora
     */
    protected void arcosArmaduraAbobora(){
        if(getSemente().equalsIgnoreCase("abobora")){
            System.out.println("Mago --> "+getNome()+" <-- | Experiência:"+getExp());
        }
    }
    /**
     * Override do método da classe Personagem para subir nível de um mago
     */
    protected void subirNivel() {
        setExp(getExp() + 1);
        setForca(getForca() * 1.05);
        setAgilidade(getAgilidade() * 1.10);
        setInteligencia(getInteligencia() * 1.20);
    }
    /**
     * Override do método da classe Personagem para imprimir estatísticas de um mago
     */
    protected void imprimeEstatisticas(){
        System.out.println("Mago --> "+getNome()+" <-- | Experiência:"+getExp()+" | Força->"+getForca()+" | Agilidade->"+getAgilidade()+" | Inteligência->"+getInteligencia()+" | Semente/Folha->"+getSemente());
    }
    /**
     * Método para aceder à variável semente
     * @return semente do mago
     */
    public String getSemente() {
        return semente;
    }
    /**
     * Método para mudar a variável semente
     * @param semente semente do mago
     */
    public void setSemente(String semente) {
        this.semente = semente;
    }
    /**
     * Método para imprimir nome e nivel de experiência de um mago
     */
    public String toString(){
        return "Mago --> "+getNome()+" <-- | Experiência:"+getExp();
    }
}


/**
 * Classe onde contém os dados da Personagem mais os dados referentes ao guerreiro
 */
public class Guerreiro extends Personagem{
    /**
     * Armadura do guerreiro
     */
    private boolean armadura;
    /**
     * Arma do guerreiro
     */
    private String arma;
    /**
     * Construtor para criar um guerreiro (Personagem)
     * @param nome nome do guerreiro
     * @param armadura armadura do guerreiro
     * @param arma arma do guerreiro
     */
    protected Guerreiro(String nome,boolean armadura,String arma){
        super(nome, 10, 5, 3);
        this.armadura=armadura;
        this.arma=arma;
    }
    /**
     * Override do método da classe Personagem para subir nível de um guerreiro
     */
    protected void subirNivel() {
        setExp(getExp() + 1);
        setForca(getForca() * 1.20);
        setAgilidade(getAgilidade() * 1.10);
        setInteligencia(getInteligencia() * 1.05);
    }
    /**
     * Override do método da classe Personagem para verificar se o guerreiro usa armadura
     */
    protected void arcosArmaduraAbobora(){
        if(isArmadura()){
            System.out.println("Guerreiro --> "+getNome()+" <-- | Experiência:"+getExp());
        }
    }
    /**
     * Função para imprimir estatísticas mostrar se tem armadura (Sim ou Não)
     * @param armadura armadura do guerreiro
     */
    protected String verifArmadura(boolean armadura){
        if(armadura){
            return "Sim";
        }else{
            return "Não";
        }
    }
    /**
     * Override do método da classe Personagem para imprimir estatísticas de um guerreiro
     */
    protected void imprimeEstatisticas(){
        System.out.println("Guerreiro --> "+getNome()+" <-- | Experiência:"+getExp()+" | Força->"+getForca()+" | Agilidade->"+getAgilidade()+" | Inteligência->"+getInteligencia()+" | Armadura->"+verifArmadura(isArmadura())+" | Arma->"+getArma());
    }

    /**
     * Método para aceder à variável armadura
     * @return armadura do guerreiro
     */
    public boolean isArmadura() {
        return armadura;
    }
    /**
     * Método para mudar à variável armadura
     * @param armadura armadura do guerreiro
     */
    public void setArmadura(boolean armadura) {
        this.armadura = armadura;
    }
    /**
     * Método para aceder à variável arma
     * @return arma do guerreiro
     */
    public String getArma() {
        return arma;
    }
    /**
     * Método para mudar a variável arma
     * @param arma arma do guerreiro
     */
    public void setArma(String arma) {
        this.arma = arma;
    }
    /**
     * Método para imprimir nome e nivel de experiência de um guerreiro
     */
    public String toString(){
        return "Guerreiro --> "+getNome()+" <-- | Experiência:"+getExp();
    }
}
